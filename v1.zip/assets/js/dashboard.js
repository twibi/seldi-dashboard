/* SELDI CMS dashboard – shared page logic.
   One page = one indicator. The page identifies itself with
   <body data-key="...">; everything else (nav, heading, chart,
   filters, PNG export) is rendered here from assets/js/data.js. */
(function () {
  "use strict";

  var YEARS_ALL = [2001, 2002, 2014, 2016, 2019, 2021, 2023, 2025];

  /* Qualitative palette, ordered for maximum contrast between neighbours. */
  var PALETTE = [
    "#b02a37", "#2563a8", "#2f9e62", "#d97706", "#7c3aed",
    "#0e7f94", "#c2417f", "#5b6472", "#8a6d1f", "#3f5ba9"
  ];

  var data = window.SELDI || [];
  var key = document.body.getAttribute("data-key");
  var entry = null;
  for (var i = 0; i < data.length; i++) {
    if (data[i].key === key) entry = data[i];
  }
  if (!entry) {
    document.body.innerHTML =
      '<p style="padding:40px;font-family:sans-serif">Unknown dashboard page: ' +
      key + "</p>";
    return;
  }

  /* ---------- state ---------- */
  var state = {
    selected: {},            // country -> bool
    from: 0,                 // index into YEARS_ALL
    to: YEARS_ALL.length - 1,
    type: "line"
  };
  entry.countries.forEach(function (c) { state.selected[c.country] = true; });

  /* ---------- top navigation (all six pages) ---------- */
  var topbar = document.createElement("header");
  topbar.className = "topbar";
  var inner = document.createElement("div");
  inner.className = "topbar-inner";
  var brand = document.createElement("a");
  brand.className = "brand";
  brand.href = data[0].page;
  brand.innerHTML = "SELDI <span>Corruption Monitoring System 2025</span>";
  inner.appendChild(brand);
  var nav = document.createElement("nav");
  nav.className = "nav";
  data.forEach(function (d) {
    var a = document.createElement("a");
    a.textContent = d.nav;
    a.href = d.page;
    if (d.key === key) a.className = "active";
    nav.appendChild(a);
  });
  inner.appendChild(nav);
  topbar.appendChild(inner);
  document.body.insertBefore(topbar, document.body.firstChild);

  /* ---------- page heading ---------- */
  var page = document.createElement("main");
  page.className = "page";

  var head = document.createElement("div");
  head.className = "page-head";

  var tag = document.createElement("div");
  tag.className = "sheet-tag";
  tag.textContent = "SELDI CMS · " + entry.sheet;
  head.appendChild(tag);

  var h1 = document.createElement("h1");
  h1.textContent = entry.title;
  head.appendChild(h1);

  if (entry.subtitle) {
    var sub = document.createElement("p");
    sub.className = "subtitle";
    sub.textContent = entry.subtitle;
    head.appendChild(sub);
  }
  if (entry.insight) {
    var ins = document.createElement("div");
    ins.className = "insight";
    ins.textContent = entry.insight;
    head.appendChild(ins);
  }
  page.appendChild(head);

  /* ---------- chart card with controls ---------- */
  var card = document.createElement("section");
  card.className = "card";

  var controls = document.createElement("div");
  controls.className = "controls";

  /* countries */
  var gC = document.createElement("div");
  gC.className = "control-group";
  gC.innerHTML = '<div class="control-label">Countries</div>';
  var pills = document.createElement("div");
  pills.className = "countries";
  entry.countries.forEach(function (c, idx) {
    var b = document.createElement("button");
    b.type = "button";
    b.className = "country-pill on";
    b.style.setProperty("--pill-color", PALETTE[idx % PALETTE.length]);
    b.innerHTML = '<span class="dot"></span>';
    b.appendChild(document.createTextNode(c.country));
    b.addEventListener("click", function () {
      state.selected[c.country] = !state.selected[c.country];
      b.classList.toggle("on", state.selected[c.country]);
      update();
    });
    pills.appendChild(b);
  });
  gC.appendChild(pills);

  var actionsP = document.createElement("div");
  actionsP.className = "pill-actions";
  var allBtn = document.createElement("button");
  allBtn.type = "button";
  allBtn.className = "mini-btn";
  allBtn.textContent = "All";
  var noneBtn = document.createElement("button");
  noneBtn.type = "button";
  noneBtn.className = "mini-btn";
  noneBtn.textContent = "None";
  actionsP.appendChild(allBtn);
  actionsP.appendChild(noneBtn);
  gC.appendChild(actionsP);
  controls.appendChild(gC);

  allBtn.addEventListener("click", function () {
    entry.countries.forEach(function (c) { state.selected[c.country] = true; });
    syncPills();
    update();
  });
  noneBtn.addEventListener("click", function () {
    entry.countries.forEach(function (c) { state.selected[c.country] = false; });
    syncPills();
    update();
  });

  function syncPills() {
    Array.prototype.forEach.call(pills.children, function (b, idx) {
      var name = entry.countries[idx].country;
      b.classList.toggle("on", state.selected[name]);
    });
  }

  /* year range */
  var gY = document.createElement("div");
  gY.className = "control-group";
  gY.innerHTML = '<div class="control-label">Survey years</div>';
  var yearsBox = document.createElement("div");
  yearsBox.className = "years";

  var fromSel = document.createElement("select");
  var toSel = document.createElement("select");
  YEARS_ALL.forEach(function (y, idx) {
    var o1 = document.createElement("option");
    o1.value = idx;
    o1.textContent = y;
    fromSel.appendChild(o1);
    var o2 = o1.cloneNode(true);
    toSel.appendChild(o2);
  });
  fromSel.value = state.from;
  toSel.value = state.to;

  fromSel.addEventListener("change", function () {
    state.from = Math.min(+fromSel.value, state.to);
    fromSel.value = state.from;
    update();
  });
  toSel.addEventListener("change", function () {
    state.to = Math.max(+toSel.value, state.from);
    toSel.value = state.to;
    update();
  });

  var dash = document.createElement("span");
  dash.textContent = "–";
  yearsBox.appendChild(fromSel);
  yearsBox.appendChild(dash);
  yearsBox.appendChild(toSel);
  gY.appendChild(yearsBox);
  controls.appendChild(gY);

  /* chart type */
  var gT = document.createElement("div");
  gT.className = "control-group";
  gT.innerHTML = '<div class="control-label">Chart type</div>';
  var seg = document.createElement("div");
  seg.className = "segmented";
  var lineBtn = document.createElement("button");
  lineBtn.type = "button";
  lineBtn.className = "seg-btn on";
  lineBtn.textContent = "Line";
  var barBtn = document.createElement("button");
  barBtn.type = "button";
  barBtn.className = "seg-btn";
  barBtn.textContent = "Bar";
  seg.appendChild(lineBtn);
  seg.appendChild(barBtn);
  gT.appendChild(seg);
  controls.appendChild(gT);

  lineBtn.addEventListener("click", function () {
    state.type = "line";
    lineBtn.classList.add("on");
    barBtn.classList.remove("on");
    update();
  });
  barBtn.addEventListener("click", function () {
    state.type = "bar";
    barBtn.classList.add("on");
    lineBtn.classList.remove("on");
    update();
  });

  /* spacer + action buttons */
  var spacer = document.createElement("div");
  spacer.className = "spacer";
  controls.appendChild(spacer);

  var gA = document.createElement("div");
  gA.className = "control-group";
  gA.innerHTML = '<div class="control-label">&nbsp;</div>';
  var act = document.createElement("div");
  act.className = "actions";

  var resetBtn = document.createElement("button");
  resetBtn.type = "button";
  resetBtn.className = "btn";
  resetBtn.textContent = "Reset";
  resetBtn.addEventListener("click", function () {
    entry.countries.forEach(function (c) { state.selected[c.country] = true; });
    state.from = 0;
    state.to = YEARS_ALL.length - 1;
    state.type = "line";
    fromSel.value = 0;
    toSel.value = state.to;
    lineBtn.classList.add("on");
    barBtn.classList.remove("on");
    syncPills();
    update();
  });

  var pngBtn = document.createElement("button");
  pngBtn.type = "button";
  pngBtn.className = "btn primary";
  pngBtn.textContent = "Save as PNG";
  pngBtn.addEventListener("click", exportPNG);

  act.appendChild(resetBtn);
  act.appendChild(pngBtn);
  gA.appendChild(act);
  controls.appendChild(gA);

  card.appendChild(controls);

  var wrap = document.createElement("div");
  wrap.className = "chart-wrap";
  var canvas = document.createElement("canvas");
  wrap.appendChild(canvas);
  var empty = document.createElement("div");
  empty.className = "empty-msg";
  empty.textContent = "Select at least one country to display the chart.";
  wrap.appendChild(empty);
  card.appendChild(wrap);

  /* notes under the chart */
  if (entry.notes.length) {
    var notes = document.createElement("div");
    notes.className = "notes";
    entry.notes.forEach(function (n) {
      var p = document.createElement("p");
      p.className = "asterisk";
      p.textContent = n;
      notes.appendChild(p);
    });
    card.appendChild(notes);
  }

  page.appendChild(card);

  var footer = document.createElement("footer");
  footer.className = "page-footer";
  footer.textContent =
    "Data: SELDI Corruption Monitoring System (CMS), " + entry.sheet +
    " worksheet of Seldi_CMS_2025.xlsx. Values are shares of the population 18+ " +
    "(shown as %). Built as a static site for GitHub Pages.";
  page.appendChild(footer);

  document.body.appendChild(page);

  /* ---------- chart ---------- */
  if (typeof Chart === "undefined") {
    wrap.innerHTML =
      '<p style="color:#b02a37">Chart.js failed to load (internet/CDN ' +
      'required). Check the connection and reload.</p>';
    return;
  }

  Chart.defaults.font.family =
    '"Segoe UI", Arial, Helvetica, sans-serif';
  Chart.defaults.color = "#4b5563";

  var chart = new Chart(canvas.getContext("2d"), buildConfig());

  function activeYears() {
    return YEARS_ALL.slice(state.from, state.to + 1);
  }

  function buildConfig() {
    var years = activeYears();
    var datasets = [];
    entry.countries.forEach(function (c, idx) {
      if (!state.selected[c.country]) return;
      var vals = years.map(function (y) {
        var v = c.values[YEARS_ALL.indexOf(y)];
        return v === null ? null : +(v * 100).toFixed(1);
      });
      var color = PALETTE[idx % PALETTE.length];
      if (state.type === "line") {
        datasets.push({
          label: c.country,
          data: vals,
          borderColor: color,
          backgroundColor: color,
          borderWidth: 2.5,
          pointRadius: 3.5,
          pointHoverRadius: 6,
          spanGaps: false,      // gaps = years the country was not surveyed
          tension: 0.15
        });
      } else {
        datasets.push({
          label: c.country,
          data: vals,
          backgroundColor: color,
          borderColor: color,
          borderWidth: 0,
          borderRadius: 3
        });
      }
    });

    return {
      type: state.type,
      data: { labels: years, datasets: datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        devicePixelRatio: 2,          // sharp export
        animation: { duration: 250 },
        interaction: { mode: "index", intersect: false },
        plugins: {
          legend: {
            position: "bottom",
            labels: { usePointStyle: true, pointStyle: "circle", padding: 16 }
          },
          tooltip: {
            callbacks: {
              label: function (ctx) {
                var v = ctx.parsed.y;
                return v === null
                  ? ctx.dataset.label + ": not surveyed"
                  : ctx.dataset.label + ": " + v + "%";
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            title: { display: true, text: "Share of population 18+ (%)" },
            ticks: { callback: function (v) { return v + "%"; } },
            grid: { color: "#eceff4" }
          },
          x: {
            title: { display: true, text: "Survey year" },
            grid: { display: false }
          }
        }
      }
    };
  }

  function update() {
    var n = 0;
    entry.countries.forEach(function (c) {
      if (state.selected[c.country]) n++;
    });
    empty.style.display = n ? "none" : "flex";
    chart.data = buildConfig().data;
    chart.options = buildConfig().options;
    chart.config.type = state.type;
    chart.update();
  }

  /* ---------- PNG export (white background + heading + source) ---------- */
  function exportPNG() {
    var src = canvas;
    var pad = 36;
    var headH = entry.subtitle || entry.insight ? 86 : 66;
    var notesTxt = entry.notes.length ? entry.notes.join("  ·  ") : "";
    var noteH = notesTxt ? 46 : 16;

    var out = document.createElement("canvas");
    out.width = src.width;
    out.height = src.height + headH + noteH;
    var ctx = out.getContext("2d");

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, out.width, out.height);

    /* heading */
    ctx.fillStyle = "#b02a37";
    ctx.font = "700 26px 'Segoe UI', Arial, sans-serif";
    ctx.textBaseline = "top";
    ctx.fillText(entry.title, pad, pad - 6);
    var yy = pad + 32;
    if (entry.insight) {
      ctx.fillStyle = "#1c2430";
      ctx.font = "italic 17px 'Segoe UI', Arial, sans-serif";
      ctx.fillText(clip(ctx, entry.insight, out.width - pad * 2), pad, yy);
      yy += 24;
    }
    if (entry.subtitle) {
      ctx.fillStyle = "#4b5563";
      ctx.font = "15px 'Segoe UI', Arial, sans-serif";
      ctx.fillText(clip(ctx, entry.subtitle, out.width - pad * 2), pad, yy);
    }

    /* chart canvas */
    ctx.drawImage(src, 0, headH);

    /* footer line */
    if (notesTxt) {
      ctx.fillStyle = "#6b7280";
      ctx.font = "13px 'Segoe UI', Arial, sans-serif";
      var foot =
        clip(ctx, notesTxt, out.width - pad * 2) +
        "  |  Source: SELDI CMS 2025";
      ctx.fillText(foot, pad, src.height + headH + 12);
    }

    var a = document.createElement("a");
    a.href = out.toDataURL("image/png");
    a.download = "seldi-" + entry.key + ".png";
    a.click();
  }

  function clip(ctx, text, maxW) {
    if (ctx.measureText(text).width <= maxW) return text;
    var t = text;
    while (t.length > 1 && ctx.measureText(t + "…").width > maxW) {
      t = t.slice(0, -1);
    }
    return t + "…";
  }
})();
